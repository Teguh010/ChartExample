export default {
  url: 'http://crm-api.id-a.pl',
  path: {
    prefix: 'api',
    storage: 'storage',
    upload: 'files/file-upload'
  }
}
