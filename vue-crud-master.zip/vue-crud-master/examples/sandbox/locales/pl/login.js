export default {
  title: 'Your App',
  login: 'E-mail',
  username: 'Nazwa użytkownika',
  password: 'Hasło',
  failed: 'Próba zalogowania nie powiodła się',
  submit: 'Zaloguj',
  passwordRequired: 'Hasło jest wymagane',
  incorrectPassword: 'Hasło ma niepoprawny format',
  loginRequired: 'Adres e-mail jest wymagany',
  incorrectLogin: 'E-mail ma niepoprawny format'
}
