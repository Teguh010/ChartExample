export default {
  home: {
    name: ''
  },
  blog: {
    name: 'Blog',
    posts: 'Posty',
    categories: 'Kategorie',
    tags: 'Tagi'
  },
  admin: {
    name: 'Administracja',
    permissions: 'Uprawnienia',
    users: 'Użytkownicy',
    userPermissions: 'Użytkownicy - uprawnienia'
  }
}
