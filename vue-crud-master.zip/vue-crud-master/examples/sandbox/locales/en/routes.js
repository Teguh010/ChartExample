export default {
  home: {
    name: ''
  },
  blog: {
    name: 'Blog',
    posts: 'Posts',
    categories: 'Categories',
    tags: 'Tags'
  },
  admin: {
    name: 'Administration',
    permissions: 'Permissions',
    users: 'Users',
    userPermissions: 'Users - permissions'
  }
}
