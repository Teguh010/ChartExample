export default {
  url: 'http://127.0.0.1:8000',
  path: {
    prefix: 'api',
    storage: 'storage',
    upload: 'files/file-upload'
  }
}
