let getters = {
  // permissions

  // user permissions

}

export default getters
