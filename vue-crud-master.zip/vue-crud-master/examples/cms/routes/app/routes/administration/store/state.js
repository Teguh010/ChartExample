let state = {
  // permissions

  // user permissions

}

export default state
