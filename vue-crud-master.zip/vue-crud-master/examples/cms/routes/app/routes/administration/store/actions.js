let actions = {
  // permissions

  // user permissions

  // users
}

export default actions
