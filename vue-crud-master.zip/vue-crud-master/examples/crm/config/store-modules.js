// custom modules
import administration from '@/routes/app/routes/administration/store/'
import crm from '@/routes/app/routes/crm/store/'

export default {
  administration,
  crm
}
