export default {
  demo: {
    tasks: 'Tasks'
  }
}
