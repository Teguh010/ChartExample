const state = {
  module: null,
  page: null,
  activeModule: '',
  profileDialog: false
}

export default state
