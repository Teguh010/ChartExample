<template>
  <v-app id="app">
    <router-view></router-view>
  </v-app>
</template>

<script>
export default {}
</script>

<style lang="stylus">
  @import "./assets/stylus/main.styl";
</style>
