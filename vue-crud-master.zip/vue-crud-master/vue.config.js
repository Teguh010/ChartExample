module.exports = {
  publicPath: './'
}
