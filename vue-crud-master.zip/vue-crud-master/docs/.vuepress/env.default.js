module.exports = {
    config: {},
    plugins: {},
};